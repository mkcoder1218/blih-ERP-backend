import type { DataTypes, ModelStatic, Sequelize } from "sequelize";

export type AuditLogModel = ModelStatic<any> & {
  associate?: (models: any) => void;
};

export default (sequelize: Sequelize, dataTypes: typeof DataTypes): AuditLogModel => {
  const AuditLog = sequelize.define(
    "AuditLog",
    {
      id: { type: dataTypes.UUID, defaultValue: dataTypes.UUIDV4, primaryKey: true },
      businessId: { type: dataTypes.UUID, allowNull: true },
      userId: { type: dataTypes.UUID, allowNull: true },
      action: { type: dataTypes.STRING(100), allowNull: false }, // CREATE, UPDATE, DELETE
      entityType: { type: dataTypes.STRING(100), allowNull: false },
      entityId: { type: dataTypes.STRING(100), allowNull: false },
      // 'success' | 'warning' | 'error'
      category: { type: dataTypes.STRING(50), allowNull: false, defaultValue: 'success' },
      beforeData: { type: dataTypes.JSONB, allowNull: true },
      afterData: { type: dataTypes.JSONB, allowNull: true },
      ipAddress: { type: dataTypes.STRING(100), allowNull: true },
      userAgent: { type: dataTypes.STRING(500), allowNull: true },
      // parsed device/browser label stored for quick display
      deviceInfo: { type: dataTypes.STRING(255), allowNull: true },
      location: { type: dataTypes.STRING(255), allowNull: true }
    },
    {
      tableName: "audit_logs",
      timestamps: true,
      updatedAt: false // Audit logs only have createdAt
    }
  ) as AuditLogModel;

  AuditLog.associate = (models: any) => {
    models.AuditLog.belongsTo(models.Business, { foreignKey: "businessId" });
    models.AuditLog.belongsTo(models.User, { foreignKey: "userId" });
  };

  return AuditLog;
};
