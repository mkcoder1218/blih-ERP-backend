import { Router } from "express";
import { validate } from "../../middlewares/validate";
import { asyncHandler } from "../../utils/asyncHandler";
import { registerSchema, loginSchema, selectWorkspaceSchema, publicRegisterSchema } from "../../validators/auth.validator";
import { AuthController } from "./auth.controller";
import { authRequired } from "../../middlewares/auth";
import { authRateLimiter, publicRegisterLimiter } from "../../middlewares/security";
import { uploadProfileImage } from "../../middlewares/profileImageUpload";
import multer from "multer";

const router = Router();
const controller = new AuthController();

// Memory storage multer for public registration (no req.user context for disk paths)
const publicUpload = multer({
  storage: multer.memoryStorage(),
  limits: { fileSize: 10 * 1024 * 1024 }, // 10MB
  fileFilter: (_req, file, cb) => {
    const allowed = ['image/jpeg', 'image/png', 'image/webp'];
    cb(null, allowed.includes(file.mimetype));
  },
});

/**
 * @openapi
 * /api/v1/auth/register:
 *   post:
 *     tags: [auth]
 *     summary: POST /register
 *     security:
 *       - bearerAuth: []
 *     responses:
 *       200:
 *         description: Success
 *       400:
 *         $ref: '#/components/responses/400'
 *       401:
 *         $ref: '#/components/responses/401'
 *       403:
 *         $ref: '#/components/responses/403'
 *       404:
 *         $ref: '#/components/responses/404'
 *       500:
 *         $ref: '#/components/responses/500'
 */
router.post("/register", uploadProfileImage.fields([{ name: "profileImage", maxCount: 1 }, { name: "documents", maxCount: 10 }]), validate(registerSchema), asyncHandler(controller.register));
/**
 * @openapi
 * /api/v1/auth/login:
 *   post:
 *     tags: [auth]
 *     summary: POST /login
 *     security:
 *       - bearerAuth: []
 *     responses:
 *       200:
 *         description: Success
 *       400:
 *         $ref: '#/components/responses/400'
 *       401:
 *         $ref: '#/components/responses/401'
 *       403:
 *         $ref: '#/components/responses/403'
 *       404:
 *         $ref: '#/components/responses/404'
 *       500:
 *         $ref: '#/components/responses/500'
 */
router.post("/login", validate(loginSchema), asyncHandler(controller.login));
router.post("/select-workspace", validate(selectWorkspaceSchema), asyncHandler(controller.selectWorkspace));

/**
 * @openapi
 * /api/v1/auth/me:
 *   get:
 *     tags: [auth]
 *     summary: GET /me
 *     security:
 *       - bearerAuth: []
 *     responses:
 *       200:
 *         description: Success
 *       401:
 *         $ref: '#/components/responses/401'
 *       403:
 *         $ref: '#/components/responses/403'
 *       500:
 *         $ref: '#/components/responses/500'
 */
router.get("/me", authRequired, asyncHandler(controller.me));

router.post("/refresh", asyncHandler(controller.refresh));
// router.post("/refresh", authRateLimiter, asyncHandler(controller.refresh));
router.post("/logout", authRequired, asyncHandler(controller.logout));

// ── Public self-registration (no auth) ────────────────────────────────────────
router.get(
  "/public-register/:businessSlug/config",
  publicRegisterLimiter,
  asyncHandler(controller.getPublicRegistrationConfig),
);

// ── Public roles list for registration form ───────────────────────────────────
router.get(
  "/public-register/:businessSlug/roles",
  publicRegisterLimiter,
  asyncHandler(controller.publicListRoles),
);

// ── Public resubmit flow — fetch pre-fill data + resubmit ──────────────────
router.get(
  "/public-register/:businessSlug/resubmit/:token",
  publicRegisterLimiter,
  asyncHandler(controller.publicGetResubmitData),
);
router.post(
  "/public-register/resubmit/:token",
  authRateLimiter,
  publicUpload.fields([
    { name: 'idDocumentFront', maxCount: 1 },
    { name: 'idDocumentBack',  maxCount: 1 },
  ]),
  asyncHandler(controller.publicResubmit),
);

// ── Public department + position lookup for registration form ─────────────────
router.get(
  "/public-register/:businessSlug/departments",
  publicRegisterLimiter,
  asyncHandler(controller.publicListDepartments),
);
router.get(
  "/public-register/:businessSlug/positions",
  publicRegisterLimiter,
  asyncHandler(controller.publicListPositions),
);
router.post(
  "/public-register",
  authRateLimiter,
  publicUpload.fields([
    { name: 'idDocumentFront', maxCount: 1 },
    { name: 'idDocumentBack',  maxCount: 1 },
  ]),
  validate(publicRegisterSchema),
  asyncHandler(controller.publicRegister),
);

export const authRoutes = router;
